package com.volkan.safetraffic;

public class Vehicle {
    private String plate;
    private float rating;
    private String comment;
    private String date;
    private String location;
    private String imageUrl;

    public Vehicle() {
    }

    public Vehicle(String plate, float rating, String comment, String date, String location, String imageUrl) {
        this.plate = plate;
        this.rating = rating;
        this.comment = comment;
        this.date = date;
        this.location = location;
        this.imageUrl = imageUrl;
    }

    public String getPlate() {
        return plate;
    }

    public float getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }

    public String getDate() {
        return date;
    }

    public String getLocation() {
        return location;
    }

    public String getImageUrl() {
        return imageUrl;

    }
}