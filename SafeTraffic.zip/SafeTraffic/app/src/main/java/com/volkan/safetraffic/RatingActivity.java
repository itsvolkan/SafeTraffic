package com.volkan.safetraffic;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class RatingActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText plateEditText;
    private RatingBar ratingBar;
    private EditText commentEditText;
    private EditText dateEditText;
    private EditText locationEditText;
    private ImageView imageView;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;
    private Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        plateEditText = findViewById(R.id.Plate);
        plateEditText.setFilters(new InputFilter[]{new UpperCaseNoSpaceInputFilter()});
        ratingBar = findViewById(R.id.ratingBar);
        commentEditText = findViewById(R.id.comment);
        dateEditText = findViewById(R.id.dateEditText);
        locationEditText = findViewById(R.id.locationEditText);
        Button submitButton = findViewById(R.id.buttonSubmit);
        imageView = findViewById(R.id.imageView);

        databaseReference = FirebaseDatabase.getInstance().getReference("vehicles");
        storageReference = FirebaseStorage.getInstance().getReference("images");
        submitButton.setOnClickListener(this::onClick);

        imageView.setOnClickListener(this::openImagePicker);
    }

    private void openImagePicker(View v) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            imageView.setImageURI(selectedImageUri);
        }
    }

    private void onClick(View v) {
        String plate = plateEditText.getText().toString().trim();
        String comment = commentEditText.getText().toString().trim();
        String date = dateEditText.getText().toString().trim();
        String location = locationEditText.getText().toString().trim();

        if (!plate.isEmpty() && !comment.isEmpty() && !date.isEmpty() && !location.isEmpty()) {
            if (selectedImageUri != null) {
                uploadImage(selectedImageUri);
            } else {
                Toast.makeText(RatingActivity.this, "Please select an image", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(RatingActivity.this, "All fields must be filled", Toast.LENGTH_SHORT).show();
        }
    }

    private void uploadImage(Uri imageUri) {
        String fileName = "image_" + System.currentTimeMillis() + ".jpg";
        StorageReference imageRef = storageReference.child(fileName);

        imageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    String imageUrl = uri.toString();

                    String plate = plateEditText.getText().toString().trim();
                    float rating = ratingBar.getRating();
                    String comment = commentEditText.getText().toString().trim();
                    String date = dateEditText.getText().toString().trim();
                    String location = locationEditText.getText().toString().trim();

                    Vehicle vehicle = new Vehicle(plate, rating, comment, date, location, imageUrl);
                    String vehicleId = databaseReference.push().getKey();
                    assert vehicleId != null;
                    databaseReference.child(vehicleId).setValue(vehicle);

                    Toast.makeText(RatingActivity.this, "Data sent successfully", Toast.LENGTH_SHORT).show();

                    plateEditText.setText("");
                    ratingBar.setRating(0);
                    commentEditText.setText("");
                    dateEditText.setText("");
                    locationEditText.setText("");
                    imageView.setImageURI(null);
                }))
                .addOnFailureListener(e -> Toast.makeText(RatingActivity.this, "Image upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
