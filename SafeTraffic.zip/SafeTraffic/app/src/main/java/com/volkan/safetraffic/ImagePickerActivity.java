package com.volkan.safetraffic;

import android.app.Activity;
import android.view.View;

public class ImagePickerActivity extends Activity {
    public void onImageClick(View view) {
    }
}
