package com.volkan.safetraffic;

import android.text.InputFilter;
import android.text.Spanned;

public class UpperCaseNoSpaceInputFilter implements InputFilter {
    @Override
    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
        String upperCaseSource = source.toString().toUpperCase();
        return upperCaseSource.replaceAll(" ", "");
    }
}
