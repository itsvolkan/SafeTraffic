package com.volkan.safetraffic;

import android.os.Bundle;
import android.text.InputFilter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class RatingListActivity extends AppCompatActivity {

    private EditText plateEditText;
    private ListView ratingListView;
    private DatabaseReference databaseReference;
    private List<Vehicle> vehicles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating_list);

        plateEditText = findViewById(R.id.plateEditText);
        plateEditText.setFilters(new InputFilter[]{new UpperCaseNoSpaceInputFilter()});

        ratingListView = findViewById(R.id.ratingListView);
        databaseReference = FirebaseDatabase.getInstance().getReference("vehicles");

        Button searchButton = findViewById(R.id.searchButton);
        searchButton.setOnClickListener(v -> {
            String plate = plateEditText.getText().toString().trim();
            if (!plate.isEmpty()) {
                searchRatingsByPlate(plate);
            } else {
                Toast.makeText(RatingListActivity.this, "Please enter a valid plate", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void searchRatingsByPlate(final String plate) {
        final ArrayList<String> ratings = new ArrayList<>();
        vehicles = new ArrayList<>();
        Query plateQuery = databaseReference.orderByChild("plate").equalTo(plate);

        plateQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot vehicleSnapshot : dataSnapshot.getChildren()) {
                    Vehicle vehicle = vehicleSnapshot.getValue(Vehicle.class);
                    if (vehicle != null) {
                        vehicles.add(vehicle);
                    }
                }

                if (vehicles.isEmpty()) {
                    Toast.makeText(RatingListActivity.this, "No ratings found for this plate", Toast.LENGTH_SHORT).show();
                } else {
                    VehicleAdapter adapter = new VehicleAdapter(RatingListActivity.this, vehicles);
                    ratingListView.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(RatingListActivity.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
