package com.volkan.safetraffic;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import java.util.List;

public class VehicleAdapter extends BaseAdapter {
    private final Context context;
    private final List<Vehicle> vehicles;

    public VehicleAdapter(Context context, List<Vehicle> vehicles) {
        this.context = context;
        this.vehicles = vehicles;
    }

    @Override
    public int getCount() {
        return vehicles.size();
    }

    @Override
    public Object getItem(int position) {
        return vehicles.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item_vehicle, parent, false);
        }

        Vehicle currentVehicle = vehicles.get(position);

        ImageView vehicleImageView = convertView.findViewById(R.id.vehicleImageView);
        vehicleImageView.setOnClickListener(v -> openImageInDialog(currentVehicle.getImageUrl()));

        TextView plateTextView = convertView.findViewById(R.id.plateTextView);
        TextView ratingTextView = convertView.findViewById(R.id.ratingTextView);
        TextView commentTextView = convertView.findViewById(R.id.commentTextView);
        TextView dateTextView = convertView.findViewById(R.id.dateTextView);
        TextView locationTextView = convertView.findViewById(R.id.locationTextView);

        plateTextView.setText("Plate: " + currentVehicle.getPlate());
        ratingTextView.setText("Rating: " + currentVehicle.getRating());
        commentTextView.setText("Comment: " + currentVehicle.getComment());
        dateTextView.setText("Date: " + currentVehicle.getDate());
        locationTextView.setText("Location: " + currentVehicle.getLocation());

        Picasso.get().load(currentVehicle.getImageUrl()).into(vehicleImageView);

        return convertView;
    }

    private void openImageInDialog(String imageUrl) {
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.image_popup_layout);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        ImageView popupImageView = dialog.findViewById(R.id.popupImageView);

        Picasso.get().load(imageUrl).into(popupImageView);

        dialog.show();
    }
}